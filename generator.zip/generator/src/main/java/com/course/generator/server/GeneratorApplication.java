package com.course.generator.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
class CourseApplication{
    public static void main(String[] args)
    {
        SpringApplication.run(CourseApplication.class, args);
    }

}
