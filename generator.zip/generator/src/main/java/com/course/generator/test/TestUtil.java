package com.course.generator.test;

public class TestUtil {
}
